from __future__ import annotations

from collections.abc import Hashable, Sequence

import torch
import torch.nn.functional as F


def clip_contrastive_loss(logits: torch.Tensor) -> torch.Tensor:
    if logits.shape[0] != logits.shape[1]:
        raise ValueError("diagonal CLIP loss requires a square logit matrix")
    labels = torch.arange(logits.size(0), device=logits.device)
    loss_i2t = F.cross_entropy(logits, labels)
    loss_t2i = F.cross_entropy(logits.t(), labels)
    return (loss_i2t + loss_t2i) / 2


def positive_mask(
    query_ids: Sequence[Hashable],
    target_ids: Sequence[Hashable],
    device: torch.device,
) -> torch.Tensor:
    target_lookup: dict[Hashable, list[int]] = {}
    for index, target_id in enumerate(target_ids):
        target_lookup.setdefault(target_id, []).append(index)
    mask = torch.zeros((len(query_ids), len(target_ids)), dtype=torch.bool, device=device)
    for query_index, query_id in enumerate(query_ids):
        indices = target_lookup.get(query_id, [])
        if indices:
            mask[query_index, torch.tensor(indices, device=device)] = True
    if not mask.any(dim=1).all():
        raise ValueError("every contrastive query must have at least one positive")
    return mask


def _multi_positive_direction(logits: torch.Tensor, positives: torch.Tensor) -> torch.Tensor:
    if logits.shape != positives.shape:
        raise ValueError("logits and positive mask must have matching shapes")
    positive_logits = logits.masked_fill(~positives, torch.finfo(logits.dtype).min)
    return (torch.logsumexp(logits, dim=1) - torch.logsumexp(positive_logits, dim=1)).mean()


def multi_positive_contrastive_loss(
    logits: torch.Tensor,
    image_ids: Sequence[Hashable],
    text_image_ids: Sequence[Hashable],
) -> torch.Tensor:
    positives = positive_mask(image_ids, text_image_ids, logits.device)
    return 0.5 * (
        _multi_positive_direction(logits, positives)
        + _multi_positive_direction(logits.t(), positives.t())
    )


class CrossBatchMemory:
    """A short detached queue that adds negatives without changing inference cost."""

    def __init__(self, capacity: int) -> None:
        self.capacity = max(0, int(capacity))
        self.image_embeddings: torch.Tensor | None = None
        self.text_embeddings: torch.Tensor | None = None
        self.image_ids: list[Hashable] = []
        self.text_image_ids: list[Hashable] = []

    def _append(self, current: torch.Tensor | None, values: torch.Tensor) -> torch.Tensor:
        combined = values.detach() if current is None else torch.cat((current, values.detach()), dim=0)
        return combined[-self.capacity :] if self.capacity else combined[:0]

    @torch.no_grad()
    def enqueue(
        self,
        image_embeddings: torch.Tensor,
        text_embeddings: torch.Tensor,
        image_ids: Sequence[Hashable],
        text_image_ids: Sequence[Hashable],
    ) -> None:
        if self.capacity == 0:
            return
        self.image_embeddings = self._append(self.image_embeddings, image_embeddings)
        self.text_embeddings = self._append(self.text_embeddings, text_embeddings)
        self.image_ids = (self.image_ids + list(image_ids))[-self.capacity :]
        self.text_image_ids = (self.text_image_ids + list(text_image_ids))[-self.capacity :]


def contrastive_loss_with_memory(
    image_embeddings: torch.Tensor,
    text_embeddings: torch.Tensor,
    logit_scale: torch.Tensor,
    image_ids: Sequence[Hashable],
    text_image_ids: Sequence[Hashable],
    memory: CrossBatchMemory | None = None,
) -> torch.Tensor:
    text_gallery = text_embeddings
    text_gallery_ids = list(text_image_ids)
    image_gallery = image_embeddings
    image_gallery_ids = list(image_ids)
    if memory is not None and memory.text_embeddings is not None:
        text_gallery = torch.cat((text_embeddings, memory.text_embeddings.to(text_embeddings.device)), dim=0)
        text_gallery_ids.extend(memory.text_image_ids)
    if memory is not None and memory.image_embeddings is not None:
        image_gallery = torch.cat((image_embeddings, memory.image_embeddings.to(image_embeddings.device)), dim=0)
        image_gallery_ids.extend(memory.image_ids)
    i2t_logits = logit_scale * image_embeddings @ text_gallery.t()
    t2i_logits = logit_scale * text_embeddings @ image_gallery.t()
    i2t_mask = positive_mask(image_ids, text_gallery_ids, i2t_logits.device)
    t2i_mask = positive_mask(text_image_ids, image_gallery_ids, t2i_logits.device)
    return 0.5 * (
        _multi_positive_direction(i2t_logits, i2t_mask)
        + _multi_positive_direction(t2i_logits, t2i_mask)
    )


def sigmoid_contrastive_loss(
    image_embeddings: torch.Tensor,
    text_embeddings: torch.Tensor,
    logit_scale: torch.Tensor,
    logit_bias: torch.Tensor,
    image_ids: Sequence[Hashable],
    text_image_ids: Sequence[Hashable],
) -> torch.Tensor:
    """SigLIP-style pairwise logistic loss, normalized by image count.

    This deliberately operates on the current batch only.  The per-image
    normalization is part of the Wave 0 pre-registration and means the loss
    magnitude grows with the number of captions per image.
    """
    if image_embeddings.ndim != 2 or text_embeddings.ndim != 2:
        raise ValueError("sigmoid contrastive embeddings must be matrices")
    if image_embeddings.shape[1] != text_embeddings.shape[1]:
        raise ValueError("image/text embedding dimensions must match")
    if image_embeddings.shape[0] != len(image_ids):
        raise ValueError("image id count does not match image embeddings")
    if text_embeddings.shape[0] != len(text_image_ids):
        raise ValueError("text id count does not match text embeddings")
    logits = logit_scale * (image_embeddings @ text_embeddings.t()) + logit_bias
    positives = positive_mask(image_ids, text_image_ids, logits.device)
    labels = positives.to(dtype=logits.dtype).mul(2).sub(1)
    return -torch.nn.functional.logsigmoid(labels * logits).sum() / max(
        1, image_embeddings.shape[0]
    )
