from __future__ import annotations

import csv
import json
import math
import os
import random
import time
from copy import deepcopy
from pathlib import Path
from typing import Any

import numpy as np
import torch
from tqdm import tqdm

from src.alignment_v3.distillation import TeacherCache, distillation_loss
from src.alignment_v3.fingerprint import Fingerprint, is_fresh, write_fingerprint
from src.alignment_v3.model import AlignmentV3Model, build_model
from src.data import build_dataloaders
from src.phase15.io_utils import atomic_json
from src.training.evaluate import evaluate_model
from src.training.losses import (
    CrossBatchMemory,
    contrastive_loss_with_memory,
    sigmoid_contrastive_loss,
)
from src.utils.config import save_config
from src.utils.device import get_device
from src.utils.logging import CSVLogger
from src.utils.seed import set_seed


def _optimizer_parameters(model: torch.nn.Module, weight_decay: float) -> list[dict[str, object]]:
    decay: list[torch.nn.Parameter] = []
    no_decay: list[torch.nn.Parameter] = []
    for name, parameter in model.named_parameters():
        if not parameter.requires_grad:
            continue
        if parameter.ndim < 2 or name.endswith("bias") or "norm" in name.lower() or "logit_scale" in name:
            no_decay.append(parameter)
        else:
            decay.append(parameter)
    return [
        {"params": decay, "weight_decay": weight_decay},
        {"params": no_decay, "weight_decay": 0.0},
    ]


def _scheduler(
    optimizer: torch.optim.Optimizer,
    total_steps: int,
    warmup_fraction: float,
) -> torch.optim.lr_scheduler.LambdaLR:
    warmup = int(total_steps * warmup_fraction)

    def value(step: int) -> float:
        if warmup and step < warmup:
            return max(1e-8, (step + 1) / warmup)
        progress = (step - warmup) / max(1, total_steps - warmup)
        return 0.5 * (1 + math.cos(math.pi * min(1.0, max(0.0, progress))))

    return torch.optim.lr_scheduler.LambdaLR(optimizer, value)


def _rng_state() -> dict[str, Any]:
    return {
        "python": random.getstate(),
        "numpy": np.random.get_state(),
        "torch": torch.get_rng_state(),
        "cuda": torch.cuda.get_rng_state_all() if torch.cuda.is_available() else None,
    }


def _restore_rng(state: dict[str, Any] | None) -> None:
    if not state:
        return
    random.setstate(state["python"])
    np.random.set_state(state["numpy"])
    torch.set_rng_state(state["torch"])
    if torch.cuda.is_available() and state.get("cuda") is not None:
        torch.cuda.set_rng_state_all(state["cuda"])


def _memory_state(memory: CrossBatchMemory) -> dict[str, Any]:
    return {
        "image_embeddings": memory.image_embeddings,
        "text_embeddings": memory.text_embeddings,
        "image_ids": memory.image_ids,
        "text_image_ids": memory.text_image_ids,
    }


def _restore_memory(memory: CrossBatchMemory, state: dict[str, Any] | None, device: torch.device) -> None:
    if not state:
        return
    memory.image_embeddings = (
        state["image_embeddings"].to(device) if state.get("image_embeddings") is not None else None
    )
    memory.text_embeddings = (
        state["text_embeddings"].to(device) if state.get("text_embeddings") is not None else None
    )
    memory.image_ids = list(state.get("image_ids", []))
    memory.text_image_ids = list(state.get("text_image_ids", []))


def _save_checkpoint(
    path: Path,
    *,
    model: AlignmentV3Model,
    optimizer: torch.optim.Optimizer,
    scheduler: torch.optim.lr_scheduler.LambdaLR,
    scaler: torch.amp.GradScaler,
    memory: CrossBatchMemory,
    epoch: int,
    config: dict[str, Any],
    metrics: dict[str, float],
    fingerprint: Fingerprint,
) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    torch.save(
        {
            "model_state": model.state_dict(),
            "optimizer_state": optimizer.state_dict(),
            "scheduler_state": scheduler.state_dict(),
            "scaler_state": scaler.state_dict(),
            "memory_state": _memory_state(memory),
            "rng_state": _rng_state(),
            "epoch": epoch,
            "config": config,
            "metrics": metrics,
            "fingerprint": fingerprint.to_dict(),
            "parameter_summary": model.parameter_summary(),
        },
        temporary,
    )
    os.replace(temporary, path)


def _save_inference_export(
    path: Path,
    model: AlignmentV3Model,
    config: dict[str, Any],
    fingerprint: Fingerprint,
    metrics: dict[str, float],
) -> None:
    inference_config = deepcopy(config)
    # Distillation heads only exist to match the teacher during training.
    # The deployment model reconstructs without them and loads strictly.
    inference_config["recipe"]["distillation"] = False
    temporary = path.with_suffix(path.suffix + ".tmp")
    torch.save(
        {
            "model_state": model.inference_state_dict(),
            "config": inference_config,
            "training_recipe": deepcopy(config["recipe"]),
            "fingerprint": fingerprint.to_dict(),
            "metrics": metrics,
            "parameter_summary": model.parameter_summary(),
            "training_only_heads_removed": True,
        },
        temporary,
    )
    os.replace(temporary, path)


def load_training_checkpoint(
    path: str | Path,
    model: AlignmentV3Model,
    *,
    device: torch.device,
    expected_fingerprint: Fingerprint | None = None,
) -> dict[str, Any]:
    checkpoint = torch.load(path, map_location=device, weights_only=False)
    if expected_fingerprint is not None:
        actual = Fingerprint.from_dict(checkpoint["fingerprint"])
        if actual.digest != expected_fingerprint.digest:
            raise ValueError(f"checkpoint fingerprint mismatch for {path}")
    model.load_state_dict(checkpoint["model_state"])
    return checkpoint


def load_inference_export(
    path: str | Path,
    *,
    device: torch.device | str = "cpu",
) -> tuple[AlignmentV3Model, dict[str, Any]]:
    checkpoint = torch.load(path, map_location=device, weights_only=False)
    model = build_model(checkpoint["config"]).to(device)
    model.load_state_dict(checkpoint["model_state"], strict=True)
    model.eval()
    return model, checkpoint


def _precision(config: dict[str, Any], device: torch.device) -> tuple[bool, torch.dtype, bool]:
    requested = str(config["training"].get("precision", "bf16")).lower()
    if device.type != "cuda":
        return False, torch.float32, False
    if requested == "bf16":
        if not torch.cuda.is_bf16_supported():
            raise RuntimeError("BF16 requested but the selected GPU does not support BF16")
        return True, torch.bfloat16, False
    if requested == "fp16":
        return True, torch.float16, True
    if requested in {"fp32", "float32"}:
        return False, torch.float32, False
    raise ValueError(f"unsupported precision {requested!r}")


def train(
    config: dict[str, Any],
    fingerprint: Fingerprint,
    *,
    resume: bool = True,
) -> dict[str, Any]:
    seed = int(config.get("seed", 42))
    set_seed(seed, deterministic=bool(config.get("deterministic", False)))
    device = get_device(str(config.get("device", "auto")))
    if device.type == "cuda":
        torch.backends.cuda.matmul.allow_tf32 = bool(config["training"].get("allow_tf32", True))
        torch.backends.cudnn.allow_tf32 = bool(config["training"].get("allow_tf32", True))
        torch.cuda.reset_peak_memory_stats(device)
    train_loader, dev_loader = build_dataloaders(config)
    model = build_model(config).to(device)
    if config["model"]["vision_encoder"] == "dinov3_convnext_tiny" and device.type == "cuda":
        model = model.to(memory_format=torch.channels_last)
    parameters = model.parameter_summary()
    budgets = config.get("budgets", {})
    if parameters["params_total_inference"] > int(budgets.get("max_total_params", 80_000_000)):
        raise ValueError(f"inference parameter budget exceeded: {parameters}")
    if parameters["params_trainable_inference"] > int(budgets.get("max_trainable_params", 5_000_000)):
        raise ValueError(f"inference-trainable parameter budget exceeded: {parameters}")

    train_cfg = config["training"]
    save_dir = Path(str(train_cfg["save_dir"]))
    save_dir.mkdir(parents=True, exist_ok=True)
    save_config(config, save_dir / "config.yaml")
    write_fingerprint(save_dir / "fingerprint.json", fingerprint)
    optimizer_kwargs = {
        "lr": float(train_cfg.get("lr", 3e-4)),
        "betas": tuple(float(value) for value in train_cfg.get("betas", [0.9, 0.98])),
    }
    try:
        optimizer = torch.optim.AdamW(
            _optimizer_parameters(model, float(train_cfg.get("weight_decay", 0.01))),
            fused=device.type == "cuda",
            **optimizer_kwargs,
        )
    except (TypeError, RuntimeError):
        optimizer = torch.optim.AdamW(
            _optimizer_parameters(model, float(train_cfg.get("weight_decay", 0.01))),
            **optimizer_kwargs,
        )
    epochs = int(train_cfg.get("epochs", 12))
    scheduler = _scheduler(
        optimizer, max(1, epochs * len(train_loader)), float(train_cfg.get("warmup_fraction", 0.05))
    )
    amp_enabled, amp_dtype, scale_gradients = _precision(config, device)
    scaler = torch.amp.GradScaler("cuda", enabled=scale_gradients)
    memory = CrossBatchMemory(int(train_cfg.get("memory_queue_size", 16384)))
    loss_type = str(config.get("recipe", {}).get("loss_type", "infonce_queue"))
    if loss_type not in {"infonce_queue", "infonce_no_queue", "sigmoid"}:
        raise ValueError(f"unsupported loss_type {loss_type!r}")
    teacher = None
    if bool(config.get("recipe", {}).get("distillation", False)):
        teacher = TeacherCache(str(config["distillation"]["cache_path"]))
    start_epoch = 1
    best_score = -1.0
    best_epoch = 0
    best_metrics: dict[str, float] = {}
    latest = save_dir / "latest.pt"
    if resume and latest.is_file():
        checkpoint = load_training_checkpoint(
            latest, model, device=device, expected_fingerprint=fingerprint
        )
        optimizer.load_state_dict(checkpoint["optimizer_state"])
        scheduler.load_state_dict(checkpoint["scheduler_state"])
        scaler.load_state_dict(checkpoint.get("scaler_state", {}))
        _restore_memory(memory, checkpoint.get("memory_state"), device)
        _restore_rng(checkpoint.get("rng_state"))
        start_epoch = int(checkpoint["epoch"]) + 1
        best_path = save_dir / "best.pt"
        if best_path.is_file():
            saved_best = torch.load(best_path, map_location="cpu", weights_only=False)
            best_metrics = dict(saved_best.get("metrics", {}))
            best_score = float(best_metrics.get("mean_R@1", -1))
            best_epoch = int(saved_best.get("epoch", 0))
    logger = CSVLogger(save_dir / "metrics.csv")
    fixed_schedule = not bool(train_cfg.get("select_on_dev", True))
    patience = int(train_cfg.get("early_stopping_patience", 3))
    without_improvement = 0
    completed_epoch = start_epoch - 1
    started_run = time.perf_counter()

    for epoch in range(start_epoch, epochs + 1):
        model.train()
        running: dict[str, float] = {
            "loss": 0.0,
            "contrastive": 0.0,
            "distillation": 0.0,
            "text_rows": 0.0,
            "unique_images": 0.0,
            "batches": 0.0,
        }
        examples = 0
        started_epoch = time.perf_counter()
        progress = tqdm(train_loader, desc=f"v3 epoch {epoch}", leave=False)
        for batch in progress:
            images = batch["images"].to(device, non_blocking=True)
            if config["model"]["vision_encoder"] == "dinov3_convnext_tiny" and device.type == "cuda":
                images = images.contiguous(memory_format=torch.channels_last)
            captions = [str(value) for value in batch["captions"]]
            image_ids = [str(value) for value in batch["image_paths"]]
            text_ids = [str(value) for value in batch.get("text_image_paths", image_ids)]
            optimizer.zero_grad(set_to_none=True)
            with torch.amp.autocast(
                device_type=device.type, enabled=amp_enabled, dtype=amp_dtype
            ):
                outputs = model(images, captions)
                if loss_type == "sigmoid":
                    contrastive = sigmoid_contrastive_loss(
                        outputs["image_embeds"],
                        outputs["text_embeds"],
                        outputs["sigmoid_logit_scale"],
                        outputs["sigmoid_logit_bias"],
                        image_ids,
                        text_ids,
                    )
                else:
                    contrastive = contrastive_loss_with_memory(
                        outputs["image_embeds"],
                        outputs["text_embeds"],
                        outputs["logit_scale"],
                        image_ids,
                        text_ids,
                        memory,
                    )
                auxiliary = torch.zeros((), device=device)
                if teacher is not None:
                    teacher_image, teacher_text = teacher.lookup(
                        image_ids, text_ids, captions, device
                    )
                    distill_cfg = config["distillation"]
                    auxiliary, _ = distillation_loss(
                        outputs,
                        teacher_image,
                        teacher_text,
                        teacher_scale=float(teacher.metadata.get("logit_scale", 1.0)),
                        temperature=float(distill_cfg.get("temperature", 2.0)),
                        image_cosine_weight=float(distill_cfg.get("image_cosine_weight", 0.25)),
                        text_cosine_weight=float(distill_cfg.get("text_cosine_weight", 0.25)),
                        kl_weight=float(distill_cfg.get("kl_weight", 1.0)),
                    )
                loss = float(train_cfg.get("contrastive_weight", 1.0)) * contrastive + float(
                    config.get("distillation", {}).get("strength", 1.0)
                ) * auxiliary
            scaler.scale(loss).backward()
            scaler.unscale_(optimizer)
            clip = float(train_cfg.get("gradient_clip_norm", 1.0))
            if clip > 0:
                torch.nn.utils.clip_grad_norm_(model.parameters(), clip)
            scaler.step(optimizer)
            scaler.update()
            scheduler.step()
            if loss_type == "infonce_queue":
                memory.enqueue(
                    outputs["image_embeds"], outputs["text_embeds"], image_ids, text_ids
                )
            with torch.no_grad():
                model.logit_scale.clamp_(max=math.log(100.0))
            batch_images = len(image_ids)
            examples += batch_images
            running["loss"] += float(loss.detach())
            running["contrastive"] += float(contrastive.detach())
            running["distillation"] += float(auxiliary.detach())
            running["text_rows"] += len(text_ids)
            running["unique_images"] += len(image_ids)
            running["batches"] += 1
            progress.set_postfix(loss=f"{float(loss.detach()):.4f}")
        elapsed = time.perf_counter() - started_epoch
        row: dict[str, float | int] = {
            "epoch": epoch,
            "train_loss": running["loss"] / max(1, len(train_loader)),
            "contrastive_loss": running["contrastive"] / max(1, len(train_loader)),
            "distillation_loss": running["distillation"] / max(1, len(train_loader)),
            "mean_loss_magnitude": running["contrastive"] / max(1, len(train_loader)),
            "unique_images_per_batch": running["unique_images"] / max(1, running["batches"]),
            "text_rows_per_batch": running["text_rows"] / max(1, running["batches"]),
            "images_per_second": examples / max(elapsed, 1e-9),
            "epoch_seconds": elapsed,
            "lr": float(optimizer.param_groups[0]["lr"]),
            "peak_training_memory_bytes": float(
                torch.cuda.max_memory_allocated(device) if device.type == "cuda" else 0
            ),
        }
        metrics: dict[str, float] = {}
        if not fixed_schedule:
            metrics = evaluate_model(
                model,
                dev_loader,
                device,
                list(config.get("evaluation", {}).get("k_values", [1, 5, 10])),
            )
            row.update(metrics)
        logger.write(row)
        print(row)
        checkpoint_metrics = {**metrics, **parameters, **{k: float(v) for k, v in row.items()}}
        _save_checkpoint(
            latest,
            model=model,
            optimizer=optimizer,
            scheduler=scheduler,
            scaler=scaler,
            memory=memory,
            epoch=epoch,
            config=config,
            metrics=checkpoint_metrics,
            fingerprint=fingerprint,
        )
        if fixed_schedule or float(metrics["mean_R@1"]) > best_score:
            best_score = float(metrics.get("mean_R@1", -1))
            best_epoch = epoch
            best_metrics = checkpoint_metrics
            without_improvement = 0
            _save_checkpoint(
                save_dir / "best.pt",
                model=model,
                optimizer=optimizer,
                scheduler=scheduler,
                scaler=scaler,
                memory=memory,
                epoch=epoch,
                config=config,
                metrics=checkpoint_metrics,
                fingerprint=fingerprint,
            )
        else:
            without_improvement += 1
        completed_epoch = epoch
        if not fixed_schedule and without_improvement >= patience:
            break

    best_path = save_dir / "best.pt"
    if not best_path.is_file():
        raise RuntimeError("training did not produce best.pt")
    best_checkpoint = load_training_checkpoint(
        best_path, model, device=device, expected_fingerprint=fingerprint
    )
    _save_inference_export(
        save_dir / "inference.pt", model, config, fingerprint, best_checkpoint["metrics"]
    )
    summary = {
        "status": "COMPLETE",
        "seed": seed,
        "best_epoch": best_epoch,
        "completed_epoch": completed_epoch,
        "fixed_schedule": fixed_schedule,
        "stopped_early": completed_epoch < epochs,
        "wall_seconds": time.perf_counter() - started_run,
        "best_metrics": best_metrics,
        "parameter_summary": parameters,
        "fingerprint_digest": fingerprint.digest,
    }
    atomic_json(summary, save_dir / "run_summary.json")
    return summary
